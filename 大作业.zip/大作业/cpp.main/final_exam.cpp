#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <stdlib.h>
#include <chrono>
#include <thread>
#include <cmath>
#include <string>
#include <vector>

using namespace std;

int main()
{
    char a;
    char b;
    char c;
    char d;

    vector<char> runners(4);

    for (i = 0, i < 4, i++)
    {
        cout << runners;
    }
}