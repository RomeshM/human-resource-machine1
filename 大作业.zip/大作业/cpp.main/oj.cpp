#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <stdlib.h>
#include <chrono>
#include <thread>
using namespace std;
int game[5];	   // 记录每个游戏完成与否
int ibox[12];	   // 记录inbox中的数字
bool ifinnum[12];  // 记录输入格是否有数字
bool ifoutnum[12]; // 记录输出格是否有数组
bool ifhand;	   // 记录手中是否有数字
int obox[12];	   // 记录outbox中的数字
int hand;		   // 记录手中数字
int blank[5];	   // 记录空地中的数字；
bool ifblank[5];
int in;
int out;					// 某步操作前输出栏的个数
int state;					// 记录游戏状态，-1为success，-2为failure；x（x>0)为第x步错；；-3为正在进行
int opnum;					// 记录步数
int inp;					// 记录输入方式，0表示键盘，1表示文件
char **op = new char *[50]; // 记录操作
bool opright;
void inputboard()
{
	// cout << "你的指令数:";
	cin >> opnum; // 记录操作步数；
	// cout << "请输入你的指令(每一行代表一步指令)：";
	for (int i = 0; i <= opnum; i++)
	{
		op[i] = new char[20];
	}
	// cout << endl;
	for (int i = 0; i <= opnum; i++)
	{
		if (i == 0)
			cin.getline(op[i], 15);
		else
		{
			// cout << "step" << i << ':';
			cin.getline(op[i], 15);
		}
	}
}
void inputfile()
{
	cout << "你需要输入操作步数与具体操作,保证一行有且仅有一步指令，如果文件准备好了，输入yes:";
	string a;
	cin >> a;
	if (a == "yes")
	{
		ifstream fin;
		fin.open("input.txt");
		fin >> opnum;
		if (fin.eof())
		{
			cout << "请正确输入指令" << endl;
			inputfile();
		}
		for (int i = 0; i <= opnum; i++)
		{
			op[i] = new char[20];
		}
		for (int i = 0; i <= opnum; i++)
		{
			if (i == 0)
				fin.getline(op[0], 15);
			else
			{
				fin.getline(op[i], 15);
				if (fin.eof() && i != opnum)
				{
					cout << "请正确输入指令数" << endl;
					inputfile();
				}
			}
		}
		fin.close();
	}
	else
	{
		inputfile();
	}
}
void page() // 制作第i关的游戏界面
{
}
void inbox()
{
	int m = in;
	if (ifinnum[1] == false)
	{
		state = -2;
		return;
	}
	hand = ibox[1];
	ifinnum[in] = false;
	in--;
	ifhand = true;
	for (int i = 1; i <= m; i++)
	{
		ibox[i] = ibox[i + 1];
	}
}
void outbox(int l)
{
	if (ifhand == false)
	{
		state = l;
		return;
	}
	out++;
	for (int i = out; i >= 1; i--)
	{
		obox[i] = obox[i - 1];
	}
	obox[1] = hand;
	ifoutnum[out] = true;
	ifhand = false;
}
void add(int m, int n) // 是第n步，加第m块空地
{
	if (ifblank[m] == false || ifhand == false)
	{
		state = n;
		return;
	}
	hand = hand + blank[m];
}
void sub(int m, int n) // 第n步，减吗、块空地
{
	if (ifblank[m] == false || ifhand == false)
	{
		state = n;
		return;
	}
	hand = hand - blank[m];
}
void copyfrom(int m, int n) // 第n步，参数m
{
	if (ifblank[m] == false || m > 3)
	{
		state = n;
		return;
	}
	hand = blank[m];
	ifhand = true;
}
void copyto(int m, int n) // 第n步，参数m
{
	if (ifhand == false || m > 3)
	{
		state = n;
		return;
	}
	ifblank[m] = true;
	blank[m] = hand;
}
void game_1() // 进行第一关
{
	state = -3; // 初始化状态
	in = 2;
	out = 0;
	ibox[1] = 1;
	ibox[2] = 2;
	obox[1] = obox[2] = -1; // 注意输出的数字也应初始化
	ifinnum[1] = ifinnum[2] = true;
	for (int i = 1; i <= 3; i++)
		ifblank[i] = 0;
	for (int i = 3; i <= 8; i++)
		ifinnum[i] = false;
	page();
	if (inp == 0) // 键盘输入
	{
		inputboard();
	}
	if (inp == 1) // 用文件输入
	{
		inputfile();
	}
	for (int i = 1; i <= opnum; i++)
	{
		// system("cls");
		if (strcmp(op[i], "inbox") == 0)
		{
			inbox();
			// page();
			// cout << endl;
			if (state == i)
				return;
		}
		else
		{
			if (strcmp(op[i], "outbox") == 0)
			{
				outbox(i);
				// page();
				// cout << endl;
				if (state == i)
					return;
			}
			else
			{
				state = i;
			};
		}
		//	std::this_thread::sleep_for(std::chrono::seconds(2));
		if (obox[1] == 2 && obox[2] == 1)
		{
			state = -1;
			game[1] = 1;
			ofstream fout;
			fout.open("finish.txt");
			for (int i = 1; i <= 4; i++)
			{
				fout << game[i] << ' ';
			}
			fout.close();
		}

		if (state != -3)
			return;
	}
	state = -2;
	return;
}
void game_2() // 进行第二关
{
	state = -3;
	ibox[1] = 3;
	ibox[2] = 9;
	ibox[3] = 5;
	ibox[4] = 1;
	ibox[5] = -2;
	ibox[6] = -2;
	ibox[7] = 9;
	ibox[8] = -9;
	for (int i = 1; i <= 8; i++)
		obox[i] = -100;
	in = 8;
	out = 0;
	for (int i = 1; i <= in; i++)
		ifinnum[i] = true;
	page();
	char oadd[4] = "add";
	char osub[4] = "sub";
	char ocopyfrom[9] = "copyfrom";
	char ocopyto[7] = "copyto";
	char ojump[5] = "jump";
	char ojumpifzero[11] = "jumpifzero";
	char spa[] = " ";
	if (inp == 0)
	{
		inputboard();
	}
	if (inp == 1)
	{
		inputfile();
	}
	for (int i = 1; i <= opnum; i++)
	{
		//	system("cls");
		opright = false;
		/*cout << "step" << i << ':' << op[i] << endl;*/
		if (strcmp(op[i], "inbox") == 0)
		{
			opright = true;
			inbox();
			// page();
			// cout << endl;
			if (state == i)
			{
				return;
			}
		}
		if (strcmp(op[i], "outbox") == 0)
		{
			opright = true;
			outbox(i);
			// page();
			// cout << endl;
			if (state == i)
				return;
		}
		if (strncmp(op[i], oadd, 3) == 0)
		{
			int u;
			opright = true;
			if (!(op[i][4] - '0' >= 1 && op[i][4] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 4, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][5] - '0' >= 1 && op[i][5] - '0' <= 9))
					u = (op[i][4] - '0');
				else
					u = (op[i][5] - '0') + 10 * (op[i][4] - '0');
				if (u >= 5)
					state = i;
				else
				{
					add(u, i);
					page();
				}
				cout << endl;
				if (state == i)
					return;
			}
		}
		if (strncmp(op[i], osub, 3) == 0)
		{
			int u;
			opright = true;
			if (!(op[i][4] - '0' >= 1 && op[i][4] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 4, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][5] - '0' >= 1 && op[i][5] - '0' <= 9))
					u = (op[i][4] - '0');
				else
					u = (op[i][5] - '0') + 10 * (op[i][4] - '0');
				if (u >= 5)
					state = i;
				else
				{
					sub(u, i);
					//	page();
				}
				// cout << endl;
				if (state == i)
					return;
			}
		}
		if (strncmp(op[i], ocopyto, 6) == 0)
		{
			int u;
			opright = true;
			if (!(op[i][7] - '0' >= 1 && op[i][7] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 7, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][8] - '0' >= 1 && op[i][8] - '0' <= 9))
					u = (op[i][7] - '0');
				else
					u = (op[i][8] - '0') + 10 * (op[i][7] - '0');
				if (u >= 5)
					state = i;
				else
				{
					copyto(u, i);
					//	page();
				}
				// cout << endl;
				if (state == i)
					return;
			}
		}
		if (strncmp(op[i], ocopyfrom, 8) == 0)
		{
			int u;
			opright = true;
			if (!(op[i][9] - '0' >= 1 && op[i][9] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 9, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][10] - '0' >= 1 && op[i][10] - '0' <= 9))
					u = (op[i][9] - '0');
				else
					u = (op[i][10] - '0') + 10 * (op[i][9] - '0');
				if (u >= 5)
					state = i;
				else
				{
					copyfrom(u, i);
					//	page();
				}
				// cout << endl;
				if (state == i)
					return;
			}
		}
		if (strncmp(op[i], ojump, 4) == 0)
		{
			int u = i;
			opright = true;
			if (!(op[i][5] - '0' >= 1 && op[i][5] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 5, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][6] - '0' >= 1 && op[i][6] - '0' <= 9))
					i = (op[i][5] - '0') - 1;
				else
					i = (op[i][6] - '0') + 10 * (op[i][5] - '0') - 1;
				if (i > opnum)
				{
					state = u;
					return;
				}
				// page();
				// cout << endl;
				if (state == i)
					return;
			}
		}
		if (strcmp(op[i], ojumpifzero) == 0)
		{
			opright = true;

			// Validation of the 5th character
			if (!(op[i][11] - '0' >= 1 && op[i][11] - '0' <= 9))
			{
				state = i;
				return;
			}

			// Validation of a single-character space
			if (strncmp(op[i] + 10, spa, 1) != 0)
			{
				state = i;
				return;
			}

			// Check if the "hand" value is zero and determine the next index
			if (hand == 0)
			{
				if (!(op[i][12] - '0' >= 1 && op[i][12] - '0' <= 9))
				{
					i = (op[i][11] - '0') - 1; // Single-digit value
				}
				else
				{
					i = (op[i][12] - '0') + 10 * (op[i][11] - '0') - 1; // Two-digit value
				}

				// Check if the new index exceeds the valid range
				if (i >= opnum)
				{
					state = i;
					return;
				}
			}

			// Call page() and validate the state
			// page();
			// cout << endl;
			if (state == i)
				return;
		}
		if (opright == false)
			state = i;
		//	std::this_thread::sleep_for(std::chrono::seconds(1));
		if (obox[1] == -18 && obox[2] == 18 && obox[3] == 0 && obox[4] == 0 && obox[5] == -4 && obox[6] == 4 && obox[7] == 6 && obox[8] == -6)
		{
			state = -1;
			game[2] = 1;
			ofstream fout;
			fout.open("finish.txt");
			for (int i = 1; i <= 4; i++)
			{
				fout << game[i] << ' ';
			}
			fout.close();
		}
		if (state != -3)
			return;
	}
	state = -2;
	return;
}
void game_3() // 进行第三关
{
	state = -3;
	ibox[1] = 6;
	ibox[2] = 2;
	ibox[3] = 7;
	ibox[4] = 7;
	ibox[5] = -9;
	ibox[6] = 3;
	ibox[7] = -3;
	ibox[8] = -3;
	for (int i = 1; i <= 8; i++)
		obox[i] = -100;
	in = 8;
	out = 0;
	for (int i = 1; i <= in; i++)
		ifinnum[i] = true;
	page();
	char oadd[4] = "add";
	char osub[4] = "sub";
	char ocopyfrom[9] = "copyfrom";
	char ocopyto[7] = "copyto";
	char ojump[5] = "jump";
	char ojumpifzero[11] = "jumpifzero";
	char spa[] = " ";
	if (inp == 0)
	{
		inputboard();
	}
	if (inp == 1)
	{
		inputfile();
	}
	for (int i = 1; i <= opnum; i++)
	{
		//	system("cls");
		opright = false;
		//	cout << "step" << i << ':' << op[i] << endl;
		if (strcmp(op[i], "inbox") == 0)
		{
			opright = true;
			inbox();
			// page();
			// cout << endl;
			if (state == i)
				return;
		}
		if (strcmp(op[i], "outbox") == 0)
		{
			opright = true;
			outbox(i);
			// page();
			// cout << endl;
			if (state == i)
				return;
		}
		if (strncmp(op[i], oadd, 3) == 0)
		{
			int u;
			opright = true;
			if (!(op[i][4] - '0' >= 1 && op[i][4] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 4, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][5] - '0' >= 1 && op[i][5] - '0' <= 9))
					u = (op[i][4] - '0');
				else
					u = (op[i][5] - '0') + 10 * (op[i][4] - '0');
				if (u >= 5)
					state = i;
				else
				{
					add(u, i);
					// page();
				}
				// cout << endl;
				if (state == i)
					return;
			}
		}
		if (strncmp(op[i], osub, 3) == 0)
		{
			int u;
			opright = true;
			if (!(op[i][4] - '0' >= 1 && op[i][4] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 4, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][5] - '0' >= 1 && op[i][5] - '0' <= 9))
					u = (op[i][4] - '0');
				else
					u = (op[i][5] - '0') + 10 * (op[i][4] - '0');
				if (u >= 5)
					state = i;
				else
				{
					sub(u, i);
					// page();
				}
				// cout << endl;
				if (state == i)
					return;
			}
		}
		if (strncmp(op[i], ocopyto, 6) == 0)
		{
			int u;
			opright = true;
			if (!(op[i][7] - '0' >= 1 && op[i][7] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 7, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][8] - '0' >= 1 && op[i][8] - '0' <= 9))
					u = (op[i][7] - '0');
				else
					u = (op[i][8] - '0') + 10 * (op[i][7] - '0');
				if (u >= 5)
					state = i;
				else
				{
					copyto(u, i);
					// page();
				}
				// cout << endl;
				if (state == i)
					return;
			}
		}
		if (strncmp(op[i], ocopyfrom, 8) == 0)
		{
			int u;
			opright = true;
			if (!(op[i][9] - '0' >= 1 && op[i][9] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 9, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][10] - '0' >= 1 && op[i][10] - '0' <= 9))
					u = (op[i][9] - '0');
				else
					u = (op[i][10] - '0') + 10 * (op[i][9] - '0');
				if (u >= 5)
					state = i;
				else
				{
					copyfrom(u, i);
					// page();
				}
				// cout << endl;
				if (state == i)
					return;
			}
		}
		if (strncmp(op[i], ojump, 4) == 0)
		{
			int u = i;
			opright = true;
			if (!(op[i][5] - '0' >= 1 && op[i][5] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 5, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][6] - '0' >= 1 && op[i][6] - '0' <= 9))
					i = (op[i][5] - '0') - 1;
				else
					i = (op[i][6] - '0') + 10 * (op[i][5] - '0') - 1;
				if (i > opnum)
				{
					state = u;
					return;
				}
				// page();
				// cout << endl;
				if (state == i)
					return;
			}
		}
		if (strcmp(op[i], ojumpifzero) == 0)
		{
			opright = true;

			// Validation of the 5th character
			if (!(op[i][11] - '0' >= 1 && op[i][11] - '0' <= 9))
			{
				state = i;
				return;
			}

			// Validation of a single-character space
			if (strncmp(op[i] + 10, spa, 1) != 0)
			{
				state = i;
				return;
			}

			// Check if the "hand" value is zero and determine the next index
			if (hand == 0)
			{
				if (!(op[i][12] - '0' >= 1 && op[i][12] - '0' <= 9))
				{
					i = (op[i][11] - '0') - 1; // Single-digit value
				}
				else
				{
					i = (op[i][12] - '0') + 10 * (op[i][11] - '0') - 1; // Two-digit value
				}

				// Check if the new index exceeds the valid range
				if (i >= opnum)
				{
					state = i;
					return;
				}
			}

			// Call page() and validate the state
			// page();
			// cout << endl;
			if (state == i)
				return;
		}

		if (opright == false)
			state = i;
		std::this_thread::sleep_for(std::chrono::seconds(1));
		if (obox[1] == -18 && obox[2] == 18 && obox[3] == 0 && obox[4] == 0 && obox[5] == -4 && obox[6] == 4 && obox[7] == 6 && obox[8] == -6)
		{
			state = -1;
			game[2] = 1;
			ofstream fout;
			fout.open("finish.txt");
			for (int i = 1; i <= 4; i++)
			{
				fout << game[i] << ' ';
			}
			fout.close();
		}
		if (state != -3)
			return;
	}
	state = -2;
	return;
}
void game_4() // 进行第四关
{
	{
		state = -3;
		ibox[1] = 3;
		ibox[2] = 2;
		ibox[3] = 1;
		ibox[4] = 1;
		ibox[5] = -4;
		ibox[6] = 5;
		ibox[7] = 8;
		ibox[8] = 8;
		for (int i = 1; i <= 8; i++)
			obox[i] = -100;
		in = 8;
		out = 0;
		for (int i = 1; i <= in; i++)
			ifinnum[i] = true;
		page();
		char oadd[4] = "add";
		char osub[4] = "sub";
		char ocopyfrom[9] = "copyfrom";
		char ocopyto[7] = "copyto";
		char ojump[5] = "jump";
		char ojumpifzero[11] = "jumpifzero";
		char spa[] = " ";
		if (inp == 0)
		{
			inputboard();
		}
		if (inp == 1)
		{
			inputfile();
		}
		for (int i = 1; i <= opnum; i++)
		{
			//		system("cls");
			opright = false;
			//		cout << "step" << i << ':' << op[i] << endl;
			if (strcmp(op[i], "inbox") == 0)
			{
				opright = true;
				inbox();
				page();
				// cout << endl;
				if (state == i)
					return;
			}
			if (strcmp(op[i], "outbox") == 0)
			{
				opright = true;
				outbox(i);
				// page();
				// cout << endl;
				if (state == i)
					return;
			}
			if (strncmp(op[i], oadd, 3) == 0)
			{
				int u;
				opright = true;
				if (!(op[i][4] - '0' >= 1 && op[i][4] - '0' <= 9))
				{
					state = i;
					return;
				}
				if (strncmp(op[i] + 4, spa, 1) == 0)
				{
					state = i;
					return;
				}
				else
				{
					if (!(op[i][5] - '0' >= 1 && op[i][5] - '0' <= 9))
						u = (op[i][4] - '0');
					else
						u = (op[i][5] - '0') + 10 * (op[i][4] - '0');
					if (u >= 5)
						state = i;
					else
					{
						add(u, i);
						// page();
					}
					// cout << endl;
					if (state == i)
						return;
				}
			}
			if (strncmp(op[i], osub, 3) == 0)
			{
				int u;
				opright = true;
				if (!(op[i][4] - '0' >= 1 && op[i][4] - '0' <= 9))
				{
					state = i;
					return;
				}
				if (strncmp(op[i] + 4, spa, 1) == 0)
				{
					state = i;
					return;
				}
				else
				{
					if (!(op[i][5] - '0' >= 1 && op[i][5] - '0' <= 9))
						u = (op[i][4] - '0');
					else
						u = (op[i][5] - '0') + 10 * (op[i][4] - '0');
					if (u >= 5)
						state = i;
					else
					{
						sub(u, i);
						// page();
					}
					// cout << endl;
					if (state == i)
						return;
				}
			}
			if (strncmp(op[i], ocopyto, 6) == 0)
			{
				int u;
				opright = true;
				if (!(op[i][7] - '0' >= 1 && op[i][7] - '0' <= 9))
				{
					state = i;
					return;
				}
				if (strncmp(op[i] + 7, spa, 1) == 0)
				{
					state = i;
					return;
				}
				else
				{
					if (!(op[i][8] - '0' >= 1 && op[i][8] - '0' <= 9))
						u = (op[i][7] - '0');
					else
						u = (op[i][8] - '0') + 10 * (op[i][7] - '0');
					if (u >= 5)
						state = i;
					else
					{
						copyto(u, i);
						// page();
					}
					// cout << endl;
					if (state == i)
						return;
				}
			}
			if (strncmp(op[i], ocopyfrom, 8) == 0)
			{
				int u;
				opright = true;
				if (!(op[i][9] - '0' >= 1 && op[i][9] - '0' <= 9))
				{
					state = i;
					return;
				}
				if (strncmp(op[i] + 9, spa, 1) == 0)
				{
					state = i;
					return;
				}
				else
				{
					if (!(op[i][10] - '0' >= 1 && op[i][10] - '0' <= 9))
						u = (op[i][9] - '0');
					else
						u = (op[i][10] - '0') + 10 * (op[i][9] - '0');
					if (u >= 5)
						state = i;
					else
					{
						copyfrom(u, i);
						page();
					}
					// cout << endl;
					if (state == i)
						return;
				}
			}
			if (strncmp(op[i], ojump, 4) == 0)
			{
				int u = i;
				opright = true;
				if (!(op[i][5] - '0' >= 1 && op[i][5] - '0' <= 9))
				{
					state = i;
					return;
				}
				if (strncmp(op[i] + 5, spa, 1) == 0)
				{
					state = i;
					return;
				}
				else
				{
					if (!(op[i][6] - '0' >= 1 && op[i][6] - '0' <= 9))
						i = (op[i][5] - '0') - 1;
					else
						i = (op[i][6] - '0') + 10 * (op[i][5] - '0') - 1;
					if (i > opnum)
					{
						state = u;
						return;
					}
					// page();
					// cout << endl;
					if (state == i)
						return;
				}
			}
			if (strcmp(op[i], ojumpifzero) == 0)
			{
				opright = true;

				// Validation of the 5th character
				if (!(op[i][11] - '0' >= 1 && op[i][11] - '0' <= 9))
				{
					state = i;
					return;
				}

				// Validation of a single-character space
				if (strncmp(op[i] + 10, spa, 1) != 0)
				{
					state = i;
					return;
				}

				// Check if the "hand" value is zero and determine the next index
				if (hand == 0)
				{
					if (!(op[i][12] - '0' >= 1 && op[i][12] - '0' <= 9))
					{
						i = (op[i][11] - '0') - 1; // Single-digit value
					}
					else
					{
						i = (op[i][12] - '0') + 10 * (op[i][11] - '0') - 1; // Two-digit value
					}

					// Check if the new index exceeds the valid range
					if (i >= opnum)
					{
						state = i;
						return;
					}
				}

				// Call page() and validate the state
				page();
				cout << endl;
				if (state == i)
					return;
			}

			if (opright == false)
				state = i;
			// std::this_thread::sleep_for(std::chrono::seconds(1));
			if (obox[1] == -18 && obox[2] == 18 && obox[3] == 0 && obox[4] == 0 && obox[5] == -4 && obox[6] == 4 && obox[7] == 6 && obox[8] == -6)
			{
				state = -1;
				game[2] = 1;
				ofstream fout;
				fout.open("finish.txt");
				for (int i = 1; i <= 4; i++)
				{
					fout << game[i] << ' ';
				}
				fout.close();
			}
			if (state != -3)
				return;
		}
		state = -2;
		return;
	}
}
void shuoming()
{
	cout << "inbox:机器人拿起输入格子第一个数，原有数被舍弃。当输入传送带上没有数时，游戏结束。" << endl
		 << endl;
	cout << "outbox:将当前s数摆在输出格子上。（机器人不再拥有当前数）" << endl
		 << endl;
	cout << "add X:将当前机器人手中积木的数字加上X 号空地上的积木。X 号空地上的积木保持不变，机器人手中积木的数字替换成加完的结果，注意X之前有空格。" << endl
		 << endl;
	cout << "sub X:将当前积木的数字减去 X 号空地上的积木。X 号空地上的积木保持不变，机器人手中积木的数字替换成减完的结果。注意X之前有空格" << endl
		 << endl;
	cout << "copyto X: 复制当前积木到 X 号空地。若 X 空地上有积木则舍弃原有积木，注意X之前有空格" << endl
		 << endl;
	cout << "coptfrom X:复制 X 号空地上的积木到当前积木,即把机器人手中积木的数字替换成 X 号空地上的积木的数字。若存在当前积木则舍弃原有当前积木,注意X之前有空格。" << endl
		 << endl;
	cout << "jump X:改变机器人的机器人程序，将后续执行的指令改为从第 X 条指令开始执行。(这里的第 X 条是指机器人程序中的第 X 条。比如假设第一条被执行过 10 次，它依旧是第一条指令)注意X之前有空格" << endl
		 << endl;
	cout << "jumpifzero X:如果当前积木为 0，则改变机器人的机器人程序，将后续执行的指令改为从第 X 条指令开始执行。如果当前积木不为 0，则不做任何操作。" << endl;
	// system("pause");
	return;
}
void setup()
{
	for (int i = 0; i <= 11; i++)
		ifinnum[i] = ifoutnum[i] = false;
	ifhand = false;
	state = -3;
	ifblank[1] = ifblank[2] = ifblank[3] = ifblank[4] = false;
	inp = 0;
	for (int i = 1; i <= 4; i++)
		game[i] = 1;
	if (inp != 0 && inp != 1)
	{
		cout << "使用正确输入方式";
		// std::this_thread::sleep_for(std::chrono::seconds(2));
		// system("cls");
		setup();
	}
	// cout << endl
	//<< "请选择要进行的关卡（输入0游戏结束，输入-1有操作介绍）：";
	int j;
	cin >> j;
	if (j != 1 && j != 2 && j != 3 && j != 4 && j != 0 && j != -1)
	{
		cout << "没有这一关啊，兄弟" << endl;
		// std::this_thread::sleep_for(std::chrono::seconds(3)); // 输出暂停3秒
		// system("cls");
		setup();
	}
	if (j == -1)
	{
		shuoming();
		cout << endl;
		// system("cls");
		setup();
	}
	if (j == 0) // 游戏结束，清除动态字符数组
	{
		for (int i = 0; i <= 19; i++)
		{
			delete[] op[i];
		}
		delete[] op;
		return;
	}
	for (int i = 1; i < j; i++)
	{
		if (game[i] == 0)
		{
			cout << "请先完成之前的关卡" << endl
				 << endl
				 << endl;
			// std::this_thread::sleep_for(std::chrono::seconds(3));
			setup();
		}
	}
	if (j == 1)
		game_1();
	if (j == 2)
		game_2();
	if (j == 3)
		game_3();
	if (j == 4)
		game_4();
	if (state == -1)
	{
		//	cout << endl
		cout << "Success" << endl;
		//	std::this_thread::sleep_for(std::chrono::seconds(3));
		//	system("cls");
		//	setup();
	}
	if (state == -2)
	{
		cout
			<< "Fail" << endl;
		//	std::this_thread::sleep_for(std::chrono::seconds(3));
		//	system("cls");
		//	setup();
	}
	if (state > 0)
	{
		cout << "Error on instruction" << ' ' << state << endl;
		//	std::this_thread::sleep_for(std::chrono::seconds(3));
		//	system("cls");
		//	setup();
	}
}
int main()
{
	setup();
	return 0;
}
