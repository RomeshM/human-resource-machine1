#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;
int main()
{
    char a;
    char b;
    char c;
    char d;
    int i[] = {1, 2, 3, 4};
    int j[] = {1, 2, 3, 4};
    std::reverse(numbers, numbers + 5);
    for (int i = 0; i < 5; i++)
    {
        std::cout << numbers[i] << " ";
    }
    std::cout << std::endl;
    return 0;
}
