#include <iostream>
#include <sstream>
#include <vector>
#include <queue>
using namespace std;

int main()
{
    string inputSeries, expectedOutputSeries, algorithm;
    int memorySize;

    // Step 1: Input handling
    cout << "Enter the input series (comma-separated): ";
    getline(cin, inputSeries);

    cout << "Enter the expected output series (comma-separated): ";
    getline(cin, expectedOutputSeries);

    cout << "Enter the memory size: ";
    cin >> memorySize;
    cin.ignore(); // Clear newline from input buffer

    cout << "Enter the algorithm (comma-separated): ";
    getline(cin, algorithm);

    // Parse the input series
    vector<int> input;
    stringstream inputSS(inputSeries);
    string token;
    while (getline(inputSS, token, ','))
    {
        input.push_back(stoi(token));
    }

    // Parse the expected output series
    vector<int> expectedOutput;
    stringstream expectedSS(expectedOutputSeries);
    while (getline(expectedSS, token, ','))
    {
        expectedOutput.push_back(stoi(token));
    }

    // Parse the algorithm
    vector<string> steps;
    stringstream algorithmSS(algorithm);
    while (getline(algorithmSS, token, ','))
    {
        steps.push_back(token);
    }

    // Simulate the algorithm
    vector<int> memory(memorySize, 0); // Memory of fixed size
    queue<int> inboxQueue;             // Input queue
    queue<int> outboxQueue;            // Output queue

    for (int val : input)
    {
        inboxQueue.push(val);
    }

    int temp = 0; // Temporary storage for the "hands"

    cout << "\nStarting simulation...\n";
    for (const string &step : steps)
    {
        if (step == "inbox")
        {
            if (!inboxQueue.empty())
            {
                temp = inboxQueue.front();
                inboxQueue.pop();
                cout << "Inbox: " << temp << endl;
            }
            else
            {
                cout << "Error: Inbox is empty!" << endl;
                break;
            }
        }
        else if (step == "copyto0")
        {
            memory[0] = temp;
            cout << "Copied to memory[0]: " << memory[0] << endl;
        }
        else if (step == "copyfrom0")
        {
            temp = memory[0];
            cout << "Copied from memory[0]: " << temp << endl;
        }
        else if (step == "outbox")
        {
            outboxQueue.push(temp);
            cout << "Outbox: " << temp << endl;
        }
        else
        {
            cout << "Error: Unknown step \"" << step << "\"!" << endl;
            break;
        }
    }

    // Check output
    vector<int> actualOutput;
    while (!outboxQueue.empty())
    {
        actualOutput.push_back(outboxQueue.front());
        outboxQueue.pop();
    }

    cout << "\nSimulation complete." << endl;
    cout << "Expected output: ";
    for (int val : expectedOutput)
    {
        cout << val << " ";
    }
    cout << "\nActual output: ";
    for (int val : actualOutput)
    {
        cout << val << " ";
    }
    cout << endl;

    if (actualOutput == expectedOutput)
    {
        cout << "Output matches expected output!" << endl;
    }
    else
    {
        cout << "Output error: Outbox does not match expected output" << endl;
    }

    return 0;
}
