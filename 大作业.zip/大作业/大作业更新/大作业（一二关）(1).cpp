#include<iostream>
#include<fstream>
#include<cstring>
#include<string>
#include<stdlib.h>
#include<chrono>
#include<thread>
using namespace std;
int game[5];//记录每个游戏完成与否
int ibox[12];//记录inbox中的数字
bool ifinnum[12];//记录输入格是否有数字
bool ifoutnum[12];//记录输出格是否有数组
bool ifhand;//记录手中是否有数字
int obox[12];//记录outbox中的数字
int hand;//记录手中数字
int blank[4];//记录空地中的数字；
bool ifblank[4];
int in;
int out;//某步操作前输出栏的个数
int state;//记录游戏状态，-1为success，-2为failure；x（x>0)为第x步错；；0为正在进行
int opnum;//记录步数
int inp;//记录输入方式，0表示键盘，1表示文件
char** op=new char*[50];//记录操作
bool opright;
void inputboard()
{
	cout<<"你的指令数:";
	cin>>opnum;//记录操作步数；
	cout<<"请输入你的指令(每一行代表一步指令)：";
	for(int i=0;i<=opnum;i++)
	{
		op[i]=new char[20];
	}
	cout<<endl;
	for(int i=0;i<=opnum;i++)
	{
		if(i==0) cin.getline(op[i],15);
		else{cout<<"step"<<i<<':';
		cin.getline(op[i],15);}
	}
}
void inputfile()
{
	cout<<"你需要输入操作步数与具体操作,保证一行有且仅有一步指令，如果文件准备好了，输入yes:";
	string a;
	cin>>a;
	if(a=="yes")
	{   ifstream fin;
		fin.open("input.txt");
		fin>>opnum;
		if(fin.eof())
		{
			cout<<"请正确输入指令"<<endl;
			inputfile();
		}
		for(int i=0;i<=opnum;i++)
		{
			op[i]=new char[20];
		}
		for(int i=0;i<=opnum;i++)
		{
			if(i==0) fin.getline(op[0],15);
			else{fin.getline(op[i],15);
			if(fin.eof()&&i!=opnum)
			{
				cout<<"请正确输入指令数"<<endl;
				inputfile();
			}}
		}
		fin.close();
	}
	else{
		inputfile();
	}
}
void page()//制作第i关的游戏界面
{
	for(int i=1;i<=17;i++)
	{
		if(i!=4&&(i<8||i>14)) cout<<"-- ";
		else cout<<' ';
	}
	cout<<endl;
	for(int j=1;j<=3;j++){
		int i=1;
		while(i<=34)
		{
			if(i==1||i==8||i==9||i==16||i==30||i==23) cout<<"| ";
			else{if(j==2&&i!=6&&i!=26&&i!=12) cout<<' ';
				if(j!=2) cout<<' ';
				if(j==2) 
				{
					if(i==5)  
					{if(ifinnum[1])
					{
						if(ibox[1]>0) cout<<ibox[1];
						else {cout<<ibox[1];
							i++;}
					}
					else cout<<' ';} 
					if(i==26) 
					{if(ifoutnum[1]) 
					{
                        cout<<obox[1];
						if(obox[1]<0) i++;
					}
						else cout<<' ';}
					if(i==12) 
					{if(ifhand) 
					{
						cout<<hand;
						if(hand<0) i++;
					}
						else cout<<' ';}
				}	
			}
			i++;
		}
		cout<<endl;
	}
	
	for(int i=1;i<=17;i++)
	{
		if(i!=4&&(i<8||i>14)) cout<<"-- ";
		else cout<<' ';
	}
	cout<<endl;
	cout<<endl;
	for(int i=1;i<=17;i++)
	{
		if(i!=4&&(i<5||i>14)) cout<<"-- ";
		else {
			if(i==5) cout<<"  -";
			if(i==6) cout<<"---";
			if(i==7) cout<<"   ";
			if(i==4||i>=8) cout<<' ';
		}
	}
	cout<<endl;
	for(int j=1;j<=2;j++)
	{
		int i=1;
		while(i<=34)
		{
			if(i==1||i==8||i==10||i==15||i==31||i==24) {
				cout<<'|';
				if(i!=10) cout<<' ';
			}
			else
			{if(j==2&&i!=6&&i!=26&&(i<11||i>=15)) cout<<' ';
				if(j!=2) {
					if(i==11) cout<<"小明";
					if(i<=10||i>=15) cout<<' ';
				}
				if(j==2) 
				{
					if(i==5) 
					{if(ifinnum[2]) 
					{
						cout<<ibox[2];
						if(ibox[2]<0) i++;
					}
						else cout<<' ';}   
					if(i==26) 
					{if(ifoutnum[2])
					{
						cout<<obox[2];
						if(obox[2]<0) i++;
					}
						else cout<<' ';}
					if(i>=10&&i<=14) cout<<'_';
				}	
			}
			i++;
		}
		cout<<endl;
	}
	for(int i=1;i<=34;i++)
	{
		if(i==1||i==8||i==12||i==31||i==24) cout<<"| ";
		else cout<<' ';
	}
	cout<<endl;
	for(int i=1;i<=24;i++)
	{
		if(i<=3||i>=22) cout<<"-- ";
		if(i==7) cout<<"\\ ";
		if(i==8) cout<<'|';
		if(i==9) cout<<" /";
		if((i>3&&i<6)||(i>9&&i<20)) cout<<' ';
	}
	cout<<endl;
	for(int i=1;i<=21;i++)
	{
		if(i!=4&&(i<5||i>18)) cout<<"-- ";
		else {
			if(i==5) cout<<"  /";
			if(i==7) cout<<" \\";
			if(i==4||i>=8) cout<<' ';
		}
	}
	cout<<endl;
	for(int i=1;i<=35;i++)
	{
		if(i==1||i==9||i==27||i==35) cout<<'|';
		else{if((i>=11&&i<=13)||(i>=16&&i<=18)||(i>=21&&i<=23)) cout<<'-';
			else cout<<' ';
		}
	}
	cout<<endl;
	for(int i=1;i<=35;i++)
	{
		if(i==1||i==9||i==11||i==14||i==16||i==19||i==21||i==24||i==27||i==35) 
		{cout<<'|';
			continue;}
		if(i==6)
		{if(ifinnum[3]) 
		{cout<<ibox[3];
			if(ibox[3]<0) i++;
			continue;}}
		if(i==12)
		{if(ifblank[1]) {
			cout<<blank[1];
			if(blank[1]<0) i++;
			continue;}
		}
		if(i==17)
		{if(ifblank[2]) {
			cout<<blank[2];
			if(blank[2]<0) i++;
			continue;}
		}
		if(i==22)
		{if(ifblank[3]) {
			cout<<blank[3];
			if(blank[3]<0) i++;
			continue;}
		}
		if(i==30)
		{if(ifoutnum[3]) 
		{cout<<obox[3];
			if(obox[3]<0) i++;
			continue;}}
		cout<<' ';
	}
	cout<<endl;
	for(int i=1;i<=35;i++)
	{
		if(i==1||i==9||i==27||i==35) cout<<'|';
		else{if((i>=11&&i<=13)||(i>=16&&i<=18)||(i>=21&&i<=23)) cout<<'-';
			else cout<<' ';
		}
	}
	cout<<endl;
	for(int i=1;i<=21;i++)
	{
		if(i!=4&&(i<5||i>18)) cout<<"-- ";
		else {
			if(i==5) cout<<"   ";
			if(i==7) cout<<"  ";
			if(i==4||i>=8) cout<<' ';
		}
	}
	cout<<endl;
	for(int i=1;i<=3;i++)
	{
		for(int j=1;j<=35;j++)
		{
			if(j==1||j==9||j==27||j==35) {cout<<'|'; 
				continue;}
			if(i==2&&j==6)
			{
				if(ifinnum[4]) 
				{cout<<ibox[4];
					if(ibox[4]<0) j++;
					continue;}
			}
			if(i==2&&j==30)
			{
				if(ifoutnum[4]) 
				{cout<<obox[4];
					if(obox[4]<0) j++;
					continue;}
			}
			cout<<' ';
		}
		cout<<endl;
	}
	for(int i=1;i<=21;i++)
	{
		if(i!=4&&(i<5||i>18)) cout<<"-- ";
		else {
			if(i==5) cout<<"   ";
			if(i==7) cout<<"  ";
			if(i==4||i>=8) cout<<' ';
		}
	}
}
void inbox(int i)
{
	int m=in;
	if(ifinnum[1]==false) 
	{
		state=i;
		return;
	}
	hand=ibox[1];
	ifinnum[in]=false;
	in--;
	ifhand=true;
	for(int i=1;i<=m;i++)
	{
		ibox[i]=ibox[i+1];
	}
}
void outbox(int l)
{
	if(ifhand==false) 
	{
		state=l;
		return;
	}
	out++;
	for(int i=out;i>=1;i--)
	{
		obox[i]=obox[i-1];
	}
	obox[1]=hand;
	ifoutnum[out]=true;
	ifhand=false;
}
void add(int m,int n)//是第n步，加第m块空地
{
	if(ifblank[m]==false||ifhand==false)
	{
		state=n;
		return;
	}
	hand=hand+blank[m];
}
void sub(int m,int n)//第n步，减吗、块空地
{
	if(ifblank[m]==false||ifhand==false)
	{
		state=n;
		return;
	}
	hand=hand-blank[m];
}
void copyfrom(int m,int n)//第n步，参数m
{
	if(ifblank[m]==false||m>3)
	{
		state=n;
		return;
	}
	hand=blank[m];
	ifhand=true;
}
void copyto(int m,int n)//第n步，参数m
{
	if(ifhand==false||m>3)
	{
		state=n;
		return;
	}
	ifblank[m]=true;
	blank[m]=hand;
}
void game_1()//进行第一关
{
	state=0;//初始化状态
	in=2;
	out=0;
	ibox[1]=1;
	ibox[2]=2;
	obox[1]=obox[2]=-1;//注意输出的数字也应初始化
	ifinnum[1]=ifinnum[2]=true;
	for(int i=1;i<=3;i++) ifblank[i]=0;
	for(int i=3;i<=8;i++) ifinnum[i]=false;
	page();
	cout<<endl<<"你的任务是将左侧数按顺序移到右侧";
	cout<<endl<<"inbox中的数字分别是：1 2.";
	cout<<endl<<"你可以使用inbox，outbox两种指令"<<endl;
	if(inp==0)//键盘输入
	{
		inputboard();
	}
	if(inp==1)//用文件输入
	{
		inputfile();
	}
	for(int i=1;i<=opnum;i++)
	{
		system("cls");
		cout<<"step"<<i<<':'<<op[i]<<endl;
		if(strcmp(op[i],"inbox")==0) 
		{
			inbox(i);
			page();
			cout<<endl;
			if(state==i) return;
		}
		else{
			if(strcmp(op[i],"outbox")==0)
			{
				outbox(i);
				page();
				cout<<endl;
				if(state==i) return;
			}
			else {
				state=i;
			};
		}
		std::this_thread::sleep_for(std::chrono::seconds(2));
		if(obox[1]==2&&obox[2]==1) 
		{
			state=-1;
			game[1]=1;
			ofstream fout;
			fout.open("finish.txt");
			for(int i=1;i<=4;i++)
			{
				fout<<game[i]<<' ';
			}
			fout.close();
		}
		
		if(state!=0) return;
	}
	state=-2;
	return;
}
void game_2()//进行第二关
{
	state=0;
	ibox[1]=3;
	ibox[2]=9;
	ibox[3]=5;
	ibox[4]=1;
	ibox[5]=-2;
	ibox[6]=-2;
	ibox[7]=9;
	ibox[8]=-9;
	for(int i=1;i<=8;i++) obox[i]=-100;
	in=8;
	out=0;
	for(int i=1;i<=in;i++) ifinnum[i]=true;
	page();
	char oadd[4]="add";
	char osub[4]="sub";
	char ocopyfrom[9]="copyfrom";
	char ocopyto[7]="copyto";
	cout<<endl<<"任务目标：对于输入序列中的每两个东西，先把第 1 个减去第 2 个，并把结果放在输出序列中，然后把第 2 个减去第 1 个，再把结果放在输出序列中，重复。";
	cout<<endl<<"inbox中的数字分别是：3,9,5,1,-2,-2,9,-9";
	cout<<endl<<"你可以使用的指令:inbox,outbox,copyfrom,copyto,add,sub";
	cout<<endl;
	if(inp==0)
	{
		inputboard();
	}
	if(inp==1)
	{
		inputfile();
	}
	for(int i=1;i<=opnum;i++)
	{
		system("cls");
		opright=false;
		cout<<"step"<<i<<':'<<op[i]<<endl;
		if(strcmp(op[i],"inbox")==0)
		{
			opright=true;
			inbox(i);
			page();
			cout<<endl;
			if(state==i) return ;
		}
		if(strcmp(op[i],"outbox")==0)
		{
			opright=true;
			outbox(i);
			page();
			cout<<endl;
			if(state==i) return;
		}
		if(strncmp(op[i],oadd,3)==0)
		{
			opright=true;
			add(op[i][4]-'0',i);
			page();
			cout<<endl;
			if(state==i) return;
		}
		if(strncmp(op[i],osub,3)==0)
		{
			opright=true;
			sub(op[i][4]-'0',i);
			page();
			cout<<endl;
			if(state==i) return;
		}
		if(strncmp(op[i],ocopyto,6)==0)
		{
			opright=true;
			
			copyto(op[i][7]-'0',i);
			page();
			cout<<endl;
			if(state==i) return;
		}
		if(strncmp(op[i],ocopyfrom,8)==0)
		{
			opright=true;
			copyfrom(op[i][9]-'0',i);
			page();
			cout<<endl;
			if(state==i) return;
		}
		if(opright==false) state=i;
		std::this_thread::sleep_for(std::chrono::seconds(2));
		if(obox[1]==-18&&obox[2]==18&&obox[3]==0&&obox[4]==0&&obox[5]==-4&&obox[6]==4&&obox[7]==6&&obox[8]==-6)
		{
			state=-1;
			game[2]=1;
			ofstream fout;
			fout.open("finish.txt");
			for(int i=1;i<=4;i++)
			{
				fout<<game[i]<<' ';
			}
			fout.close();
		}
		if(state!=0) return;
	}
	state=-2;
	return;
}
void game_3()//进行第三关
{
	cout<<"还在做，别急";
	std::this_thread::sleep_for(std::chrono::seconds(3));//输出暂停3秒
	system("cls");
	return;
}
void game_4()//进行第四关
{
	cout<<"还在做，别急";
	std::this_thread::sleep_for(std::chrono::seconds(3));//输出暂停3秒
	system("cls");
	return;
}
void  setup()
{
	for(int m=1;m<=25;m++) cout<<' ';
	cout<<"欢迎来到罗美和李雨桐的human resource machine!!!!(^～^)"<<endl;
	for(int m=1;m<=40;m++) cout<<' ';
	cout<<"请帮助小明完成老板给的任务"<<endl;
	for(int i=0;i<=11;i++) ifinnum[i]=ifoutnum[i]=false;
	ifhand=false;
	state=0;
	ifstream fin;//获知各关卡完成情况
	fin.open("finish.txt");
	for(int i=1;i<=4;i++) fin>>game[i];
	fin.close();
	for(int i=1;i<=4;i++)
	{	
		for(int m=1;m<=45;m++) cout<<' ';
		cout<<"Task"<<i<< ":";
		if(game[i]==1) cout<<"finished"<<endl;
		else cout<<"waiting"<<endl;
	}
	cout<<"请选择你的输入方式(0表示键盘输入，1表示从'input'文件输入):";//确定输入方式
	cin>>inp;
	if(inp!=0&&inp!=1) {cout<<"使用正确输入方式";
		std::this_thread::sleep_for(std::chrono::seconds(2));
		system("cls");
		setup();
	}
	cout<<endl<<"请选择要进行的关卡（输入0游戏结束）：";
	int j;
	cin>>j;
	if(j!=1&&j!=2&&j!=3&&j!=4&&j!=0) 
	{cout<<"没有这一关啊，兄弟"<<endl;
		std::this_thread::sleep_for(std::chrono::seconds(3));//输出暂停3秒
		system("cls");
		setup();}
	if(j==0)//游戏结束，清除动态字符数组
	{
		for(int i=0;i<=19;i++)
		{
			delete[] op[i]; 
		}
		delete[] op;
		return;
	}
	for(int i=1;i<j;i++)
	{
		if(game[i]==0)
		{
			cout<<"请先完成之前的关卡"<<endl<<endl<<endl;
			std::this_thread::sleep_for(std::chrono::seconds(3));
			setup();
		}
	}
	if(j==1) game_1();
	if(j==2) game_2();
	if(j==3) game_3();
	if(j==4) game_4();
	if(state==-1)
	{
		cout<<endl<<"success"<<endl;
		std::this_thread::sleep_for(std::chrono::seconds(3));
		system("cls");
		setup();
	}
	if(state==-2)
	{
		cout<<endl<<"failure"<<endl;
		std::this_thread::sleep_for(std::chrono::seconds(3));
		system("cls");
		setup();
	}
	if(state>0)
	{
		cout<<"Error on instruction"<<' '<<state<<endl;
		std::this_thread::sleep_for(std::chrono::seconds(3));
		system("cls");
		setup();
	}
}
int main()
{
	setup();
	return 0;
}
