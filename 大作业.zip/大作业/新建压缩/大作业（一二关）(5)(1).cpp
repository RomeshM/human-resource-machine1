#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <stdlib.h>
#include <chrono>
#include <thread>
#include <windows.h>
using namespace std;
int game[5];	   // 记录每个游戏完成与否
int ibox[12];	   // 记录inbox中的数字
bool ifinnum[12];  // 记录输入格是否有数字
bool ifoutnum[12]; // 记录输出格是否有数组
bool ifhand;	   // 记录手中是否有数字
int obox[12];	   // 记录outbox中的数字
int hand;		   // 记录手中数字
int blank[5];	   // 记录空地中的数字；
bool ifblank[5];
int in;
int out;					// 某步操作前输出栏的个数
int state;					// 记录游戏状态，-1为success，-2为failure；x（x>0)为第x步错；；-3为正在进行
int opnum;					// 记录步数
int inp;					// 记录输入方式，0表示键盘，1表示文件
char **op = new char *[50]; // 记录操作
bool opright;
void inputboard()
{
	cout << "你的指令数:";
	cin >> opnum; // 记录操作步数；
	cout << "请输入你的指令(每一行代表一步指令)：";
	for (int i = 0; i <= opnum; i++)
	{
		op[i] = new char[20];
	}
	cout << endl;
	for (int i = 0; i <= opnum; i++)
	{
		if (i == 0)
			cin.getline(op[i], 15);
		else
		{
			cout << "step" << i << ':';
			cin.getline(op[i], 15);
		}
	}
}
void inputfile()
{
	cout << "你需要输入操作步数与具体操作,保证一行有且仅有一步指令，如果文件准备好了，输入yes:";
	string a;
	cin >> a;
	if (a == "yes")
	{
		ifstream fin;
		fin.open("input.txt");
		fin >> opnum;
		if (fin.eof())
		{
			cout << "请正确输入指令" << endl;
			inputfile();
		}
		for (int i = 0; i <= opnum; i++)
		{
			op[i] = new char[20];
		}
		for (int i = 0; i <= opnum; i++)
		{
			if (i == 0)
				fin.getline(op[0], 15);
			else
			{
				fin.getline(op[i], 15);
				if (fin.eof() && i != opnum)
				{
					cout << "请正确输入指令数" << endl;
					inputfile();
				}
			}
		}
		fin.close();
	}
	else
	{
		inputfile();
	}
}
void page(int p) // 制作第i关的游戏界面
{
	for (int i = 1; i <= 60; i++)
	{
		if (i != 4 && (i < 4 || (i > 4 + p && i < 8 + p) || i > 57))
			cout << "-- ";
		else
			cout << ' ';
	}
	cout << endl;
	for (int j = 1; j <= 3; j++)
	{
		int i = 1;
		while (i <= 73)
		{
			if (i == 1 || i == 8 || i == 9 + p || i == 16 + p || i == 73 || i == 66)
				cout << "| ";
			else
			{
				if (j == 2 && i != 5 && i != 69 && i != 12 + p)
					cout << ' ';
				if (j != 2)
					cout << ' ';
				if (j == 2)
				{
					if (i == 5)
					{
						if (ifinnum[1])
						{
							cout << ibox[1];
							if (ibox[1] < 0 || ibox[1] >= 10)
								i++;
							if (ibox[1] <= -10)
								i++;
						}
						else
							cout << ' ';
					}
					if (i == 69)
					{
						if (ifoutnum[1])
						{
							cout << obox[1];
							if (obox[1] < 0 || obox[1] >= 10)
								i++;
							if (obox[1] <= -10)
								i++;
						}
						else
							cout << ' ';
					}
					if (i == 12 + p)
					{
						if (ifhand)
						{
							cout << hand;
							if (hand < 0 || hand >= 10)
								i++;
							if (hand <= -10)
								i++;
						}
						else
							cout << ' ';
					}
				}
			}
			i++;
		}
		cout << endl;
	}
	for (int i = 1; i <= 60; i++)
	{
		if (i != 4 && (i < 4 || (i > 4 + p && i < 8 + p) || i > 57))
			cout << "-- ";
		else
			cout << ' ';
	}
	cout << endl;
	cout << endl;
	for (int i = 1; i <= 61; i++)
	{
		if (i < 4 || i > 58)
			cout << "-- ";
		else
		{
			if (i == 5 + p)
				cout << " -";
			if (i == 6 + p)
				cout << "---";
			if (i == 7 + p)
				cout << "   ";
			if (i < 5 + p || i > 7 + p)
				cout << ' ';
		}
	}
	cout << endl;
	for (int j = 1; j <= 2; j++)
	{
		for (int i = 1; i <= 76; i++)
		{
			if (i == 1 || i == 9 || i == 11 + p || i == 14 + p || i == 76 || i == 68)
			{
				cout << '|';
			}
			else
			{
				if (j == 2 && i != 5 && i != 69 && (i < 11 + p || i >= 15 + p))
					cout << ' ';
				if (j != 2)
				{
					if (i == 12 + p)
						cout << "小明";
					if (i <= 10 + p || i >= 15 + p)
						cout << ' ';
				}
				if (j == 2)
				{
					if (i == 5)
					{
						if (ifinnum[2])
						{
							cout << ibox[2];
							if (ibox[2] < 0 || ibox[2] >= 10)
								i++;
							if (ibox[2] <= -10)
								i++;
						}
						else
							cout << ' ';
					}
					if (i == 71)
					{
						if (ifoutnum[2])
						{
							cout << obox[2];
							if (obox[2] < 0 || obox[2] >= 10)
								i++;
							if (obox[2] <= -10)
								i++;
						}
						else
							cout << ' ';
					}
					if (i >= 12 + p && i <= 13 + p)
						cout << "__";
				}
			}
		}
		cout << endl;
	}
	for (int i = 1; i <= 74; i++)
	{
		if (i == 1 || i == 8 || i == 12 + p || i == 74 || i == 67)
			cout << "| ";
		else
			cout << ' ';
	}
	cout << endl;
	for (int i = 1; i <= 65; i++)
	{
		if (i <= 3 || i >= 63)
			cout << "-- ";
		if (i == 7 + p)
			cout << "\\ ";
		if (i == 8 + p)
			cout << '|';
		if (i == 9 + p)
			cout << " /";
		if ((i > 3 && i < 6 + p) || (i > 9 + p && i < 63))
			cout << ' ';
	}
	cout << endl;
	for (int i = 1; i <= 64; i++)
	{
		if (i != 4 && (i < 5 || i > 61))
			cout << "-- ";
		else
		{
			if (i == 5 + p)
				cout << "  /";
			if (i == 7 + p)
				cout << " \\";
			if (i <= 4 + p || i >= 8 + p)
				cout << ' ';
		}
	}
	cout << endl;
	for (int i = 1; i <= 78; i++)
	{
		if (i == 1 || i == 9 || i == 70 || i == 78)
			cout << '|';
		else
		{
			if ((i >= 17 && i <= 21) || (i >= 30 && i <= 34) || (i >= 43 && i <= 47) || (i >= 56 && i <= 60))
				cout << '-';
			else
				cout << ' ';
		}
	}
	cout << endl;
	for (int i = 1; i <= 78; i++)
	{
		if (i == 1 || i == 9 || i == 17 || i == 21 || i == 30 || i == 34 || i == 43 || i == 47 || i == 56 || i == 60 || i == 78 || i == 70)
		{
			cout << '|';
			continue;
		}
		if (i == 5)
		{
			if (ifinnum[3])
			{
				cout << ibox[3];
				if (ibox[3] < 0 || ibox[2] >= 10)
					i++;
				if (ibox[3] <= -10)
					i++;
				continue;
			}
		}
		if (i == 19)
		{
			if (ifblank[1])
			{
				cout << blank[1];
				if (blank[1] < 0 || blank[1] >= 10)
					i++;
				if (blank[1] <= -10)
					i++;
				continue;
			}
		}
		if (i == 32)
		{
			if (ifblank[2])
			{
				cout << blank[2];
				if (blank[2] < 0 || blank[2] >= 10)
					i++;
				if (blank[2] <= -10)
					i++;
				continue;
			}
		}
		if (i == 45)
		{
			if (ifblank[3])
			{
				cout << blank[3];
				if (blank[3] < 0 || blank[3] >= 10)
					i++;
				if (blank[3] <= -10)
					i++;
				continue;
			}
		}
		if (i == 58)
		{
			if (ifblank[4])
			{
				cout << blank[4];
				if (blank[4] < 0 || blank[4] >= 10)
					i++;
				if (blank[4] <= -10)
					i++;
				continue;
			}
		}
		if (i == 73)
		{
			if (ifoutnum[3])
			{
				cout << obox[3];
				if (obox[3] < 0 || obox[3] >= 10)
					i++;
				if (obox[3] <= -10)
					i++;
				continue;
			}
		}
		cout << ' ';
	}
	cout << endl;
	for (int i = 1; i <= 78; i++)
	{
		if (i == 1 || i == 9 || i == 70 || i == 78)
			cout << '|';
		else
		{
			if ((i >= 17 && i <= 21) || (i >= 30 && i <= 34) || (i >= 43 && i <= 47) || (i >= 56 && i <= 60))
				cout << '-';
			else
				cout << ' ';
		}
	}
	cout << endl;
	for (int i = 1; i <= 66; i++)
	{
		if (i != 4 && (i < 4 || i > 63))
			cout << "-- ";
		else
			cout << ' ';
	}
	cout << endl;
	cout << endl;
	for (int i = 1; i <= 66; i++)
	{
		if (i != 4 && (i < 4 || i > 63))
			cout << "-- ";
		else
			cout << ' ';
	}
	cout << endl;
	for (int i = 1; i <= 3; i++)
	{
		for (int j = 1; j <= 78; j++)
		{
			if (j == 1 || j == 9 || j == 70 || j == 78)
			{
				cout << '|';
				continue;
			}
			if (i == 2 && j == 5)
			{
				if (ifinnum[4])
				{
					cout << ibox[4];
					if (ibox[4] < 0 || ibox[4] >= 10)
						j++;
					if (ibox[4] <= -10)
						i++;
					continue;
				}
			}
			if (i == 2 && j == 73)
			{
				if (ifoutnum[4])
				{
					cout << obox[4];
					if (obox[4] < 0 || obox[4] >= 10)
						j++;
					if (obox[4] <= -10)
						i++;
					continue;
				}
			}
			cout << ' ';
		}
		cout << endl;
	}
	for (int i = 1; i <= 66; i++)
	{
		if (i != 4 && (i < 4 || i > 63))
			cout << "-- ";
		else
			cout << ' ';
	}
	cout << endl;
}
void inbox()
{
	int m = in;
	if (ifinnum[1] == false)
	{
		state = -2;
		return;
	}
	hand = ibox[1];
	ifinnum[in] = false;
	in--;
	ifhand = true;
	for (int i = 1; i <= m; i++)
	{
		ibox[i] = ibox[i + 1];
	}
}
void outbox(int l)
{
	if (ifhand == false)
	{
		state = l;
		return;
	}
	out++;
	for (int i = out; i >= 1; i--)
	{
		obox[i] = obox[i - 1];
	}
	obox[1] = hand;
	ifoutnum[out] = true;
	ifhand = false;
}
void add(int m, int n) // 是第n步，加第m块空地
{
	if (ifblank[m] == false || ifhand == false)
	{
		state = n;
		return;
	}
	hand = hand + blank[m];
}
void sub(int m, int n) // 第n步，减吗、块空地
{
	if (ifblank[m] == false || ifhand == false)
	{
		state = n;
		return;
	}
	hand = hand - blank[m];
}
void copyfrom(int m, int n) // 第n步，参数m
{
	if (ifblank[m] == false || m > 3)
	{
		state = n;
		return;
	}
	hand = blank[m];
	ifhand = true;
}
void copyto(int m, int n) // 第n步，参数m
{
	if (ifhand == false || m > 5)
	{
		state = n;
		return;
	}
	ifblank[m] = true;
	blank[m] = hand;
}
void game_1() // 进行第一关
{
	state = -3; // 初始化状态
	in = 2;
	out = 0;
	ibox[1] = 1;
	ibox[2] = 2;
	obox[1] = obox[2] = -1; // 注意输出的数字也应初始化
	ifinnum[1] = ifinnum[2] = true;
	for (int i = 1; i <= 3; i++)
		ifblank[i] = 0;
	for (int i = 3; i <= 8; i++)
		ifinnum[i] = false;
	page(0);
	cout << endl
		 << "你的任务是将左侧数按顺序移到右侧";
	cout << endl
		 << "inbox中的数字分别是：1 2.";
	cout << endl
		 << "你可以使用inbox，outbox两种指令" << endl;
	if (inp == 0) // 键盘输入
	{
		inputboard();
	}
	if (inp == 1) // 用文件输入
	{
		inputfile();
	}
	for (int i = 1; i <= opnum; i++)
	{
		system("cls");
		cout << "step" << i << ':' << op[i] << endl;
		if (strcmp(op[i], "inbox") == 0)
		{
			inbox();
			page(0);
			cout << endl;
			if (state == i)
				return;
		}
		else
		{
			if (strcmp(op[i], "outbox") == 0)
			{
				outbox(i);
				page(45);
				cout << endl;
				if (state == i)
					return;
			}
			else
			{
				state = i;
			};
		}
		std::this_thread::sleep_for(std::chrono::seconds(2));
		if (obox[1] == 2 && obox[2] == 1 && i == opnum)
		{
			state = -1;
			game[1] = 1;
			ofstream fout;
			fout.open("finish.txt");
			for (int i = 1; i <= 4; i++)
			{
				fout << game[i] << ' ';
			}
			fout.close();
		}

		if (state != -3)
			return;
	}
	state = -2;
	return;
}
void game_2() // 进行第二关
{
	state = -3;
	ibox[1] = 3;
	ibox[2] = 9;
	ibox[3] = 5;
	ibox[4] = 1;
	ibox[5] = -2;
	ibox[6] = -2;
	ibox[7] = 9;
	ibox[8] = -9;
	for (int i = 1; i <= 8; i++)
		obox[i] = -100;
	in = 8;
	out = 0;
	for (int i = 1; i <= in; i++)
		ifinnum[i] = true;
	page(0);
	char oadd[4] = "add";
	char osub[4] = "sub";
	char ocopyfrom[9] = "copyfrom";
	char ocopyto[7] = "copyto";
	char ojump[5] = "jump";
	char ojumpifzero[11] = "jumpifzero";
	char spa[] = " ";
	cout << endl
		 << "任务目标：对于输入序列中的每两个东西，先把第 1 个减去第 2 个，并把结果放在输出序列中，然后把第 2 个减去第 1 个，再把结果放在输出序列中，重复。";
	cout << endl
		 << "inbox中的数字分别是：3,9,5,1,-2,-2,9,-9";
	cout << endl
		 << "你可以使用的指令:inbox,outbox,copyfrom,copyto,add,sub,jump, jumpifzero";
	cout << endl;
	if (inp == 0)
	{
		inputboard();
	}
	if (inp == 1)
	{
		inputfile();
	}
	int cyc = 0;
	for (int i = 1; i <= opnum; i++)
	{
		cyc++;
		if (cyc >= 80)
		{
			cout << endl
				 << "操作次数过多,可能进入死循环" << endl;
			state = -2;
			return;
		}
		system("cls");
		opright = false;
		cout << "step" << i << ':' << op[i] << endl;
		if (strcmp(op[i], "inbox") == 0)
		{
			opright = true;
			inbox();
			page(0);
			cout << endl;
			if (state == i)
			{
				return;
			}
		}
		if (strcmp(op[i], "outbox") == 0)
		{
			opright = true;
			outbox(i);
			page(45);
			cout << endl;
			if (state == i)
				return;
		}
		if (strncmp(op[i], oadd, 3) == 0)
		{
			int u;
			opright = true;
			if (!(op[i][4] - '0' >= 1 && op[i][4] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 4, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][5] - '0' >= 1 && op[i][5] - '0' <= 9))
					u = (op[i][4] - '0');
				else
					u = (op[i][5] - '0') + 10 * (op[i][4] - '0');
				if (u >= 5)
					state = i;
				else
				{
					add(u, i);
					page(u * 14 - 14);
				}
				cout << endl;
				if (state == i)
					return;
			}
		}
		if (strncmp(op[i], osub, 3) == 0)
		{
			int u;
			opright = true;
			if (!(op[i][4] - '0' >= 1 && op[i][4] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 4, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][5] - '0' >= 1 && op[i][5] - '0' <= 9))
					u = (op[i][4] - '0');
				else
					u = (op[i][5] - '0') + 10 * (op[i][4] - '0');
				if (u >= 5)
					state = i;
				else
				{
					sub(u, i);
					page(u * 14 - 14);
				}
				cout << endl;
				if (state == i)
					return;
			}
		}
		if (strncmp(op[i], ocopyto, 6) == 0)
		{
			int u;
			opright = true;
			if (!(op[i][7] - '0' >= 1 && op[i][7] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 7, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][8] - '0' >= 1 && op[i][8] - '0' <= 9))
					u = (op[i][7] - '0');
				else
					u = (op[i][8] - '0') + 10 * (op[i][7] - '0');
				if (u >= 5)
					state = i;
				else
				{
					copyto(u, i);
					page(u * 14 - 14);
				}
				cout << endl;
				if (state == i)
					return;
			}
		}
		if (strncmp(op[i], ocopyfrom, 8) == 0)
		{
			int u;
			opright = true;
			if (!(op[i][9] - '0' >= 1 && op[i][9] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 9, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][10] - '0' >= 1 && op[i][10] - '0' <= 9))
					u = (op[i][9] - '0');
				else
					u = (op[i][10] - '0') + 10 * (op[i][9] - '0');
				if (u >= 5)
					state = i;
				else
				{
					copyfrom(u, i);
					page(u * 14 - 14);
				}
				cout << endl;
				if (state == i)
					return;
			}
		}
		if (strncmp(op[i], ojump, 4) == 0 && strlen(op[i]) <= 7)
		{
			int u = i;
			opright = true;
			if (!(op[i][5] - '0' >= 1 && op[i][5] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 5, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][6] - '0' >= 1 && op[i][6] - '0' <= 9))
					i = (op[i][5] - '0') - 1;
				else
					i = (op[i][6] - '0') + 10 * (op[i][5] - '0') - 1;
				if (i > opnum)
				{
					state = u;
					return;
				}
				page(0);
				cout << endl;
				if (state == i)
					return;
			}
		}
		if (strcmp(op[i], ojumpifzero) == 0)
		{
			opright = true;

			// Validation of the 5th character
			if (!(op[i][11] - '0' >= 1 && op[i][11] - '0' <= 9))
			{
				state = i;
				return;
			}

			// Validation of a single-character space
			if (strncmp(op[i] + 10, spa, 1) != 0)
			{
				state = i;
				return;
			}

			// Check if the "hand" value is zero and determine the next index
			if (hand == 0)
			{
				if (!(op[i][12] - '0' >= 1 && op[i][12] - '0' <= 9))
				{
					i = (op[i][11] - '0') - 1; // Single-digit value
				}
				else
				{
					i = (op[i][12] - '0') + 10 * (op[i][11] - '0') - 1; // Two-digit value
				}

				// Check if the new index exceeds the valid range
				if (i >= opnum)
				{
					state = i;
					return;
				}
			}

			// Call page() and validate the state
			page(0);
			cout << endl;
			if (state == i)
				return;
		}
		if (opright == false)
			state = i;
		std::this_thread::sleep_for(std::chrono::seconds(1));
		if (obox[1] == -18 && obox[2] == 18 && obox[3] == 0 && obox[4] == 0 && obox[5] == -4 && obox[6] == 4 && obox[7] == 6 && obox[8] == -6)
		{
			state = -1;
			game[2] = 1;
			ofstream fout;
			fout.open("finish.txt");
			for (int i = 1; i <= 4; i++)
			{
				fout << game[i] << ' ';
			}
			fout.close();
		}
		if (state != -3)
			return;
	}
	state = -2;
	return;
}
void game_3() // 进行第三关
{
	state = -3;
	ibox[1] = 6;
	ibox[2] = 2;
	ibox[3] = 7;
	ibox[4] = 7;
	ibox[5] = -9;
	ibox[6] = 3;
	ibox[7] = -3;
	ibox[8] = -3;
	for (int i = 1; i <= 8; i++)
		obox[i] = -100;
	in = 8;
	out = 0;
	for (int i = 1; i <= in; i++)
		ifinnum[i] = true;
	page(0);
	char oadd[4] = "add";
	char osub[4] = "sub";
	char ocopyfrom[9] = "copyfrom";
	char ocopyto[7] = "copyto";
	char ojump[5] = "jump";
	char ojumpifzero[11] = "jumpifzero";
	char spa[] = " ";
	cout << endl
		 << "任务目标：对于输入序列中的每两个东西，先把第 1 个减去第 2 个，并把结果放在输出序列中，然后把第 2 个减去第 1 个，再把结果放在输出序列中，重复。";
	cout << endl
		 << "inbox中的数字分别是：3,9,5,1,-2,-2,9,-9";
	cout << endl
		 << "你可以使用的指令:inbox,outbox,copyfrom,copyto,add,sub,jump, jumpifzero";
	cout << endl;
	if (inp == 0)
	{
		inputboard();
	}
	if (inp == 1)
	{
		inputfile();
	}
	int cyc = 0;
	for (int i = 1; i <= opnum; i++)
	{
		cyc++;
		if (cyc >= 80)
		{
			cout << endl
				 << "操作次数过多，可能进入死循环" << endl;
			state = -2;
			return;
		}
		system("cls");
		opright = false;
		cout << "step" << i << ':' << op[i] << endl;
		if (strcmp(op[i], "inbox") == 0)
		{
			opright = true;
			inbox();
			page(0);
			cout << endl;
			if (state == i)
				return;
		}
		if (strcmp(op[i], "outbox") == 0)
		{
			opright = true;
			outbox(i);
			page(45);
			cout << endl;
			if (state == i)
				return;
		}
		if (strncmp(op[i], oadd, 3) == 0)
		{
			int u;
			opright = true;
			if (!(op[i][4] - '0' >= 1 && op[i][4] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 4, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][5] - '0' >= 1 && op[i][5] - '0' <= 9))
					u = (op[i][4] - '0');
				else
					u = (op[i][5] - '0') + 10 * (op[i][4] - '0');
				if (u >= 5)
					state = i;
				else
				{
					add(u, i);
					page(u * 14 - 14);
				}
				cout << endl;
				if (state == i)
					return;
			}
		}
		if (strncmp(op[i], osub, 3) == 0)
		{
			int u;
			opright = true;
			if (!(op[i][4] - '0' >= 1 && op[i][4] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 4, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][5] - '0' >= 1 && op[i][5] - '0' <= 9))
					u = (op[i][4] - '0');
				else
					u = (op[i][5] - '0') + 10 * (op[i][4] - '0');
				if (u >= 5)
					state = i;
				else
				{
					sub(u, i);
					page(u * 14 - 14);
				}
				cout << endl;
				if (state == i)
					return;
			}
		}
		if (strncmp(op[i], ocopyto, 6) == 0)
		{
			int u;
			opright = true;
			if (!(op[i][7] - '0' >= 1 && op[i][7] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 7, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][8] - '0' >= 1 && op[i][8] - '0' <= 9))
					u = (op[i][7] - '0');
				else
					u = (op[i][8] - '0') + 10 * (op[i][7] - '0');
				if (u >= 5)
					state = i;
				else
				{
					copyto(u, i);
					page(u * 14 - 14);
				}
				cout << endl;
				if (state == i)
					return;
			}
		}
		if (strncmp(op[i], ocopyfrom, 8) == 0)
		{
			int u;
			opright = true;
			if (!(op[i][9] - '0' >= 1 && op[i][9] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 9, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][10] - '0' >= 1 && op[i][10] - '0' <= 9))
					u = (op[i][9] - '0');
				else
					u = (op[i][10] - '0') + 10 * (op[i][9] - '0');
				if (u >= 5)
					state = i;
				else
				{
					copyfrom(u, i);
					page(u * 14 - 14);
				}
				cout << endl;
				if (state == i)
					return;
			}
		}
		if (strncmp(op[i], ojump, 4) == 0 && strlen(op[i]) <= 7)
		{
			int u = i;
			opright = true;
			if (!(op[i][5] - '0' >= 1 && op[i][5] - '0' <= 9))
			{
				state = i;
				return;
			}
			if (strncmp(op[i] + 5, spa, 1) == 0)
			{
				state = i;
				return;
			}
			else
			{
				if (!(op[i][6] - '0' >= 1 && op[i][6] - '0' <= 9))
					i = (op[i][5] - '0') - 1;
				else
					i = (op[i][6] - '0') + 10 * (op[i][5] - '0') - 1;
				if (i > opnum)
				{
					state = u;
					return;
				}
				page(0);
				cout << endl;
				if (state == i)
					return;
			}
		}
		if (strncmp(op[i], ojumpifzero, 10) == 0)
		{
			int u = i;
			opright = true;
			if (hand == 0)
			{
				if (!(op[i][12] - '0' >= 0 && op[i][12] - '0' <= 9))
				{
					i = (op[i][11] - '0') - 1;
				}
				else
				{
					i = (op[i][12] - '0') + 10 * (op[i][11] - '0') - 1;
				}
				if (i >= opnum)
				{
					state = u;

					return;
				}
			}
			if (state == u)
				return;
		}

		if (opright == false)
			state = i;
		std::this_thread::sleep_for(std::chrono::seconds(1));
		if (obox[1] == -3 && obox[2] == 7)
		{
			state = -1;
			game[3] = 1;
			ofstream fout;
			fout.open("finish.txt");
			for (int i = 1; i <= 4; i++)
			{
				fout << game[i] << ' ';
			}
			fout.close();
		}
		if (state != -3)
			return;
	}
	state = -2;
	return;
}
void game_4() // 进行第四关
{
	{
		state = -3;
		ibox[1] = 3;
		ibox[2] = 2;
		ibox[3] = 1;
		ibox[4] = 1;
		ibox[5] = -4;
		ibox[6] = 5;
		ibox[7] = 8;
		ibox[8] = 8;
		for (int i = 1; i <= 8; i++)
			obox[i] = -100;
		in = 8;
		out = 0;
		for (int i = 1; i <= in; i++)
			ifinnum[i] = true;
		page(0);
		char oadd[4] = "add";
		char osub[4] = "sub";
		char ocopyfrom[9] = "copyfrom";
		char ocopyto[7] = "copyto";
		char ojump[5] = "jump";
		char ojumpifzero[11] = "jumpifzero";
		char spa[] = " ";
		cout << endl
			 << "任务目标：如果两数字相等，将它们相加，并将结果发送到右侧格子。如果两数字不相等，将第一个数字减去第二个数字，并将结果发送到右侧格子。";
		cout << endl
			 << "inbox中的数字分别是：3,2,1,1,-4,5,8,8";
		cout << endl
			 << "你可以使用的指令:inbox,outbox,copyfrom,copyto,add,sub,jump, jumpifzero";
		cout << endl;
		if (inp == 0)
		{
			inputboard();
		}
		if (inp == 1)
		{
			inputfile();
		}
		int cyc = 0;
		for (int i = 1; i <= opnum; i++)
		{
			cyc++;
			if (cyc >= 80)
			{
				cout << endl
					 << "操作次数过多,可能进入死循环" << endl;
				state = -2;
				return;
			}
			system("cls");
			opright = false;
			cout << "step" << i << ':' << op[i] << endl;
			if (strcmp(op[i], "inbox") == 0)
			{
				opright = true;
				inbox();
				page(0);
				cout << endl;
				if (state == i)
					return;
			}
			if (strcmp(op[i], "outbox") == 0)
			{
				opright = true;
				outbox(i);
				page(45);
				cout << endl;
				if (state == i)
					return;
			}
			if (strncmp(op[i], oadd, 3) == 0)
			{
				int u;
				opright = true;
				if (!(op[i][4] - '0' >= 1 && op[i][4] - '0' <= 9))
				{
					state = i;
					return;
				}
				if (strncmp(op[i] + 4, spa, 1) == 0)
				{
					state = i;
					return;
				}
				else
				{
					if (!(op[i][5] - '0' >= 1 && op[i][5] - '0' <= 9))
						u = (op[i][4] - '0');
					else
						u = (op[i][5] - '0') + 10 * (op[i][4] - '0');
					if (u >= 5)
						state = i;
					else
					{
						add(u, i);
						page(u * 14 - 14);
					}
					cout << endl;
					if (state == i)
						return;
				}
			}
			if (strncmp(op[i], osub, 3) == 0)
			{
				int u;
				opright = true;
				if (!(op[i][4] - '0' >= 1 && op[i][4] - '0' <= 9))
				{
					state = i;
					return;
				}
				if (strncmp(op[i] + 4, spa, 1) == 0)
				{
					state = i;
					return;
				}
				else
				{
					if (!(op[i][5] - '0' >= 1 && op[i][5] - '0' <= 9))
						u = (op[i][4] - '0');
					else
						u = (op[i][5] - '0') + 10 * (op[i][4] - '0');
					if (u >= 5)
						state = i;
					else
					{
						sub(u, i);
						page(u * 14 - 14);
					}
					cout << endl;
					if (state == i)
						return;
				}
			}
			if (strncmp(op[i], ocopyto, 6) == 0)
			{
				int u;
				opright = true;
				if (!(op[i][7] - '0' >= 1 && op[i][7] - '0' <= 9))
				{
					state = i;
					return;
				}
				if (strncmp(op[i] + 7, spa, 1) == 0)
				{
					state = i;
					return;
				}
				else
				{
					if (!(op[i][8] - '0' >= 1 && op[i][8] - '0' <= 9))
						u = (op[i][7] - '0');
					else
						u = (op[i][8] - '0') + 10 * (op[i][7] - '0');
					if (u >= 5)
						state = i;
					else
					{
						copyto(u, i);
						page(u * 14 - 14);
					}
					cout << endl;
					if (state == i)
						return;
				}
			}
			if (strncmp(op[i], ocopyfrom, 8) == 0)
			{
				int u;
				opright = true;
				if (!(op[i][9] - '0' >= 1 && op[i][9] - '0' <= 9))
				{
					state = i;
					return;
				}
				if (strncmp(op[i] + 9, spa, 1) == 0)
				{
					state = i;
					return;
				}
				else
				{
					if (!(op[i][10] - '0' >= 1 && op[i][10] - '0' <= 9))
						u = (op[i][9] - '0');
					else
						u = (op[i][10] - '0') + 10 * (op[i][9] - '0');
					if (u >= 5)
						state = i;
					else
					{
						copyfrom(u, i);
						page(u * 14 - 14);
					}
					cout << endl;
					if (state == i)
						return;
				}
			}
			if (strncmp(op[i], ojump, 4) == 0 && strlen(op[i]) <= 7)
			{
				int u = i;
				opright = true;
				if (!(op[i][5] - '0' >= 1 && op[i][5] - '0' <= 9))
				{
					state = i;
					return;
				}
				if (strncmp(op[i] + 5, spa, 1) == 0)
				{
					state = i;
					return;
				}
				else
				{
					if (!(op[i][6] - '0' >= 1 && op[i][6] - '0' <= 9))
						i = (op[i][5] - '0') - 1;
					else
						i = (op[i][6] - '0') + 10 * (op[i][5] - '0') - 1;
					if (i > opnum)
					{
						state = u;
						return;
					}
					page(0);
					cout << endl;
					if (state == i)
						return;
				}
			}
			if (strncmp(op[i], ojumpifzero, 10) == 0)
			{
				int u = i;
				opright = true;
				if (hand == 0)
				{
					if (!(op[i][12] - '0' >= 0 && op[i][12] - '0' <= 9))
					{
						i = (op[i][11] - '0') - 1;
					}
					else
					{
						i = (op[i][12] - '0') + 10 * (op[i][11] - '0') - 1;
					}
					if (i >= opnum)
					{
						state = u;

						return;
					}
				}
				if (state == u)
					return;
			}

			if (opright == false)
				state = i;
			std::this_thread::sleep_for(std::chrono::seconds(1));
			if (obox[1] == 16 && obox[2] == 9 && obox[3] == 2 && obox[4] == -1)
			{
				state = -1;
				game[4] = 1;
				ofstream fout;
				fout.open("finish.txt");
				for (int i = 1; i <= 4; i++)
				{
					fout << game[i] << ' ';
				}
				fout.close();
			}
			if (state != -3)
				return;
		}
		state = -2;
		return;
	}
}
void shuoming()
{
	cout << "inbox:机器人拿起输入格子第一个数，原有数被舍弃。当输入传送带上没有数时，游戏结束。" << endl
		 << endl;
	cout << "outbox:将当前s数摆在输出格子上。（机器人不再拥有当前数）" << endl
		 << endl;
	cout << "add X:将当前机器人手中积木的数字加上X 号空地上的积木。X 号空地上的积木保持不变，机器人手中积木的数字替换成加完的结果，注意X之前有空格。" << endl
		 << endl;
	cout << "sub X:将当前积木的数字减去 X 号空地上的积木。X 号空地上的积木保持不变，机器人手中积木的数字替换成减完的结果。注意X之前有空格" << endl
		 << endl;
	cout << "copyto X: 复制当前积木到 X 号空地。若 X 空地上有积木则舍弃原有积木，注意X之前有空格" << endl
		 << endl;
	cout << "coptfrom X:复制 X 号空地上的积木到当前积木,即把机器人手中积木的数字替换成 X 号空地上的积木的数字。若存在当前积木则舍弃原有当前积木,注意X之前有空格。" << endl
		 << endl;
	cout << "jump X:改变机器人的机器人程序，将后续执行的指令改为从第 X 条指令开始执行。(这里的第 X 条是指机器人程序中的第 X 条。比如假设第一条被执行过 10 次，它依旧是第一条指令)注意X之前有空格" << endl
		 << endl;
	cout << "jumpifzero X:如果当前积木为 0，则改变机器人的机器人程序，将后续执行的指令改为从第 X 条指令开始执行。如果当前积木不为 0，则不做任何操作。" << endl;
	system("pause");
	return;
}
void setup()
{
	for (int m = 1; m <= 25; m++)
		cout << ' ';
	cout << "欢迎来到罗美和李雨桐的human resource machine!!!!(^～^)" << endl;
	for (int m = 1; m <= 40; m++)
		cout << ' ';
	cout << "请帮助小明完成老板给的任务" << endl;
	for (int i = 0; i <= 11; i++)
		ifinnum[i] = ifoutnum[i] = false;
	ifhand = false;
	state = -3;
	ifblank[1] = ifblank[2] = ifblank[3] = ifblank[4] = false;
	ifstream fin; // 获知各关卡完成情况
	fin.open("finish.txt");
	for (int i = 1; i <= 4; i++)
		fin >> game[i];
	fin.close();
	for (int i = 1; i <= 4; i++)
	{
		for (int m = 1; m <= 45; m++)
			cout << ' ';
		cout << "Task" << i << ":";
		if (game[i] == 1)
			cout << "finished" << endl;
		else
			cout << "waiting" << endl;
	}
	cout << "请选择你的输入方式(0表示键盘输入，1表示从文件输入,若使用文件输入，第x关对应game_input_x文件):"; // 确定输入方式
	cin >> inp;
	if (inp != 0 && inp != 1)
	{
		cout << "使用正确输入方式";
		std::this_thread::sleep_for(std::chrono::seconds(2));
		system("cls");
		setup();
	}
	cout << endl
		 << "请选择要进行的关卡（输入0游戏结束，输入-1有操作介绍）：";
	char gam[100];
	int j;
	cin >> gam;
	if (strlen(gam) == 2)
	{
		if (strcmp(gam, "-1") != 0)
		{
			cout << endl
				 << "请正确输入" << endl;
			setup();
		}
		else
			j = -1;
	}
	if (strlen(gam) >= 3)
	{
		setup();
	}
	if (strlen(gam) == 1)
	{
		j = gam[0] - '0';
	}
	if (j != 1 && j != 2 && j != 3 && j != 4 && j != 0 && j != -1)
	{
		cout << "没有这一关啊，兄弟" << endl;
		std::this_thread::sleep_for(std::chrono::seconds(3)); // 输出暂停3秒
		system("cls");
		setup();
	}
	if (j == -1)
	{
		shuoming();
		cout << endl;
		system("cls");
		setup();
	}
	if (j == 0) // 游戏结束，清除动态字符数组
	{
		for (int i = 0; i <= 19; i++)
		{
			delete[] op[i];
		}
		delete[] op;
		return;
	}
	for (int i = 1; i < j; i++)
	{
		if (game[i] == 0)
		{
			cout << "请先完成之前的关卡" << endl
				 << endl
				 << endl;
			std::this_thread::sleep_for(std::chrono::seconds(3));
			setup();
		}
	}
	if (j == 1)
		game_1();
	if (j == 2)
		game_2();
	if (j == 3)
		game_3();
	if (j == 4)
		game_4();
	if (state == -1)
	{
		cout << endl
			 << "success" << endl;
		std::this_thread::sleep_for(std::chrono::seconds(3));
		system("cls");
		setup();
	}
	if (state == -2)
	{
		cout << endl
			 << "failure" << endl;
		std::this_thread::sleep_for(std::chrono::seconds(3));
		system("cls");
		setup();
	}
	if (state > 0)
	{
		cout << "Error on instruction" << ' ' << state << endl;
		std::this_thread::sleep_for(std::chrono::seconds(3));
		system("cls");
		setup();
	}
}
int main()
{
	setup();
	return 0;
}
