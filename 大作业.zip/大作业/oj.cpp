#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <stdlib.h>
#include <chrono>
#include <thread>
using namespace std;
int game[5];	   // 记录每个游戏完成与否
int ibox[12];	   // 记录inbox中的数字
bool ifinnum[12];  // 记录输入格是否有数字
bool ifoutnum[12]; // 记录输出格是否有数组
bool ifhand;	   // 记录手中是否有数字
int obox[12];	   // 记录outbox中的数字
int hand;		   // 记录手中数字
int blank[5];	   // 记录空地中的数字；
bool ifblank[5];
int in;
int out;					// 某步操作前输出栏的个数
int state;					// 记录游戏状态，-1为success，-2为failure；x（x>0)为第x步错；；-3为正在进行
int opnum;					// 记录步数
int inp;					// 记录输入方式，0表示键盘，1表示文件
char **op = new char *[50]; // 记录操作
bool opright;
void inputboard()
{
	cin >> opnum; 
	for (int i = 0; i <= opnum; i++)
	{
		op[i] = new char[20];
	}
	for (int i = 0; i <= opnum; i++)
	{
		if (i == 0)
			cin.getline(op[i], 15);
		else
		{
			cin.getline(op[i], 15);
		}
	}
}

void inbox()
{
	int m = in;
	if (ifinnum[1] == false)
	{
		state = -2;
		return;
	}
	hand = ibox[1];
	ifinnum[in] = false;
	in--;
	ifhand = true;
	for (int i = 1; i <= m-1; i++)
	{
		ibox[i] = ibox[i + 1];
	}
}
void outbox(int l)
{
	if (ifhand == false)
	{
		state = l;
		return;
	}
	out++;
	for (int i = out; i >= 1; i--)
	{
		obox[i] = obox[i - 1];
	}
	obox[1] = hand;
	ifoutnum[out] = true;
	ifhand = false;
}
void add(int m, int n) // 是第n步，加第m块空地
{
	if (ifblank[m] == false || ifhand == false)
	{
		state = n;
		return;
	}
	hand = hand + blank[m];
}
void sub(int m, int n) // 第n步，减吗、块空地
{
	if (ifblank[m] == false || ifhand == false)
	{
		state = n;
		return;
	}
	hand = hand - blank[m];
}
void copyfrom(int m, int n) // 第n步，参数m
{
	if (ifblank[m] == false || m >=3)
	{
		state = n;
		return;
	}
	hand = blank[m];
	ifhand = true;
}
void copyto(int m, int n) // 第n步，参数m
{
	if (ifhand == false || m >=3)
	{
		state = n;
		return;
	}
	ifblank[m] = true;
	blank[m] = hand;
}
void game_1() // 进行第一关
{
	state = -3; // 初始化状态
	in = 2;
	out = 0;
	ibox[1] = 1;
	ibox[2] = 2;
	obox[1] = obox[2] = -1; // 注意输出的数字也应初始化
	ifinnum[1] =true;
	ifinnum[2] = true;
	for (int i = 1; i <= 4; i++)
		ifblank[i] = false;
	for (int i = 3; i <= 8; i++)
		ifinnum[i] = false;
	inputboard();
	
	for (int i = 1; i <= opnum; i++)
	{
		//system("cls");
		if (strcmp(op[i], "inbox") == 0)
		{
			inbox();
			if (state == i)
				return;
			if(state==-2)
				return;
		}
		else
		{
			if (strcmp(op[i], "outbox") == 0)
			{
				outbox(i);
				if (state == i)
					return;
			}
			else
			{
				state = i;
				return;
			};
		}
	//	std::this_thread::sleep_for(std::chrono::seconds(2));
		if (obox[1] == 2 && obox[2] == 1&&i==opnum)
		{
			state =-1;		
		}
		
		if (state != -3)
			return;
	}
	state = -2;
	return;
  }
void game_2() // 进行第二关
{
	state = -3;
	ibox[1] = 3;
	ibox[2] = 9;
	ibox[3] = 5;
	ibox[4] = 1;
	ibox[5] = -2;
	ibox[6] = -2;
	ibox[7] = 9;
	ibox[8] = -9;
	for (int i = 1; i <= 8; i++)
		obox[i] = -100;
	in = 8;
	out = 0;
	for (int i = 1; i <= in; i++)
		ifinnum[i] = true;
	char oadd[4] = "add";
	char osub[4] = "sub";
	char ocopyfrom[9] = "copyfrom";
	char ocopyto[7] = "copyto";
	char ojump[5] = "jump";
	char ojumpifzero[11] = "jumpifzero";
	if (inp == 0)
	{
		inputboard();
	}
	for (int i = 1; i <= opnum; i++)
	{
		opright = false;
		if (strcmp(op[i], "inbox") == 0)
		{
			opright = true;
			inbox();
			if (state == i){
				return;}
		}
		if (strcmp(op[i], "outbox") == 0)
		{
			opright = true;
			outbox(i);
			if (state == i)
				return;
		}
		if (strncmp(op[i], oadd, 3) == 0)
		{
			opright=true;
			if(op[i][4]-'0'>=3||((op[i][10] - '0')>=0&&(op[i][10] - '0')<=9)){
				state=i;
				return;
			}
			add(op[i][4]-'0', i);
			if (state == i) return;
		}
		if (strncmp(op[i], osub, 3) == 0)
		{
			opright=true;
			if(op[i][4]-'0'>=3||((op[i][5] - '0')>=0&&(op[i][5] - '0')<=9)) 
			{
				state=i;
				return;
			}
			sub(op[i][4]-'0', i);
			if (state == i) return;
		}
		if (strncmp(op[i], ocopyto, 6) == 0)
		{
			opright=true;
			int u;
			u = (op[i][7] - '0');
			if (u >= 3||((op[i][8] - '0')>=0&&(op[i][8] - '0')<=9))
			{state = i;
				return;}
			else
			{
				copyto(u, i);
			}
			if (state == i)  return;
		}
		if (strncmp(op[i], ocopyfrom, 8) == 0)
		{
			int u;
			opright = true;
			u = (op[i][9] - '0');
			if (u >= 3||((op[i][10] - '0')>=0&&(op[i][10] - '0')<=9))
			{	state = i;
				return;}
			else
			{
				copyfrom(u, i);
			}
			if (state == i)
				return;
		}
		if (strncmp(op[i], ojump, 4) == 0&&strlen(op[i])<=7)
		{
			int u = i;
			opright = true;
			if (!(op[i][6] - '0' >= 1 && op[i][6] - '0' <= 9))
				i = (op[i][5] - '0') - 1;
			else
				i = (op[i][6] - '0') + 10 * (op[i][5] - '0') - 1;
			if (i > opnum)
			{
				state = u;
				return;
			}
		}
		if (strncmp(op[i], ojumpifzero,10) == 0)
		{
			int u=i;
			opright = true;
			if (hand == 0)
			{
				if (!(op[i][12] - '0' >= 0&& op[i][12] - '0' <= 9))
				{
					i = (op[i][11] - '0') - 1; 
				}
				else
				{
					i = (op[i][12] - '0') + 10 * (op[i][11] - '0') - 1;
				}
				if (i >= opnum)
				{
					state = u;
					return;
				}
			}
		}
		if (opright == false)
		{	state = i;
		return;}
		if (obox[1] == -18 && obox[2] == 18 && obox[3] == 0 && obox[4] == 0 && obox[5] == -4 && obox[6] == 4 && obox[7] == 6 && obox[8] == -6)
		{
			state = -1;
		}
		if (state != -3)
			return;
	}
	state = -2;
	return;
}
void game_3() // 进行第三关
{
	state = -3;
	ibox[1] = 6;
	ibox[2] = 2;
	ibox[3] = 7;
	ibox[4] = 7;
	ibox[5] = -9;
	ibox[6] = 3;
	ibox[7] = -3;
	ibox[8] = -3;
	for (int i = 1; i <= 8; i++)
		obox[i] = -100;
	in = 8;
	out = 0;
	for (int i = 1; i <= in; i++)
		ifinnum[i] = true;
	char oadd[4] = "add";
	char osub[4] = "sub";
	char ocopyfrom[9] = "copyfrom";
	char ocopyto[7] = "copyto";
	char ojump[5] = "jump";
	char ojumpifzero[11] = "jumpifzero";
	if (inp == 0)
	{
		inputboard();
	}
	for (int i = 1; i <= opnum; i++)
	{
		opright = false;
		if (strcmp(op[i], "inbox") == 0)
		{
			opright = true;
			inbox();
			if (state == i){
				return;}
		}
		if (strcmp(op[i], "outbox") == 0)
		{
			opright = true;
			outbox(i);
			if (state == i)
				return;
		}
		if (strncmp(op[i], oadd, 3) == 0)
		{
			opright=true;
			add(op[i][4]-'0', i);
			cout << endl;
			if (state == i) return;
		}
		if (strncmp(op[i], osub, 3) == 0)
		{
			opright=true;
			sub(op[i][4]-'0', i);
			//	page();
			//cout << endl;
			if (state == i) return;
		}
		if (strncmp(op[i], ocopyto, 6) == 0)
		{
			opright=true;
			int u;
			if (!(op[i][8] - '0' >= 1 && op[i][8] - '0' <= 9))
				u = (op[i][7] - '0');
			else
				u = (op[i][8] - '0') + 10 * (op[i][7] - '0');
			if (u >= 3)
				state = i;
			else
			{
				copyto(u, i);
			}
			if (state == i)  return;
		}
		if (strncmp(op[i], ocopyfrom, 8) == 0)
		{
			int u;
			opright = true;
			if (!(op[i][10] - '0' >= 1 && op[i][10] - '0' <= 9))
				u = (op[i][9] - '0');
			else
				u = (op[i][10] - '0') + 10 * (op[i][9] - '0');
			if (u >= 5)
				state = i;
			else
			{
				copyfrom(u, i);
			}
			if (state == i)
				return;
		}
		if (strncmp(op[i], ojump, 4) == 0&&strlen(op[i])<=7)
		{
			int u = i;
			opright = true;
			if (!(op[i][6] - '0' >= 1 && op[i][6] - '0' <= 9))
				i = (op[i][5] - '0') - 1;
			else
				i = (op[i][6] - '0') + 10 * (op[i][5] - '0') - 1;
			if (i > opnum)
			{
				state = u;
				return;
			}
			if (state == i)
				return;
		}
		if (strncmp(op[i], ojumpifzero,10) == 0)
		{
			int u=i;
			opright = true;
			if (hand == 0)
			{
				if (!(op[i][12] - '0' >= 0&& op[i][12] - '0' <= 9))
				{
					i = (op[i][11] - '0') - 1; 
				}
				else
				{
					i = (op[i][12] - '0') + 10 * (op[i][11] - '0') - 1;
				}
				if (i >= opnum)
				{
					state = u;

					return;
				}
			}
			if (state == u)
				return;
		}
		if (opright == false)
			state = i;
		if (obox[1] == -3 && obox[2] == 7)
		{
			state = -1;
			game[3] = 1;
		}
		if (state != -3)
			return;
	}
	state = -2;
	return;
}
void setup()
{
	for (int i = 0; i <= 11; i++)
		ifinnum[i] = ifoutnum[i] = false;
	ifhand = false;
	state = -3;
	ifblank[1]=ifblank[2]=ifblank[0]=false;
	inp=0;
	for(int i=1;i<=4;i++) game[i]=1;
	int j;
	cin >> j;
	if (j == 1)
		game_1();
	if (j == 2)
		game_2();
	if (j == 3)
		game_3();
	if (state == -1)
	{
		cout<< "Success" << endl;
	}
	if (state == -2)
	{
		cout << "Fail" << endl;
	}
	if (state > 0)
	{
		cout << "Error on instruction" << ' ' << state << endl;
	}
}
int main()
{
	setup();
	return 0;
}
